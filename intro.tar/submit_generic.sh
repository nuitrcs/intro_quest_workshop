#!/bin/bash
#MSUB -A b1042             # <allocationID> 
#MSUB -q genomics          # <queue_type>
#MSUB -l nodes=1:ppn=1
#MSUB -l walltime=00:10:00
#MSUB -N sample_job
#MSUB -j oe
##MSUB -o                   # <-- can provide name here 
##MSUB -e                   # <-- can provide name here


cd $PBS_O_WORKDIR ## Move to the directory from which the job was submitted
module load python  ## Load necessary modules (software pr libraries)

python helloworld.py ## Run the program
