#!/usr/bin/env python
"""
Sleepy Hello World
"""

import sys
from time import sleep

sleep(180)  # wait for 180 seconds

greeting = "\nHello, World!\n\n"
sys.stdout.write(greeting)

with open('message.txt','w') as my_output:
    my_output.write(greeting)

